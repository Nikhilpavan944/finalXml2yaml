package com.cg.osce.apibuilder.pojo;

public class Constants {

	public static final String FILELOCATION = "src/main/resources/apiDocument/apiDocument.yaml";
	public static final String XMLAPPLICATION="application/xml";
	public static final String JSONAPPLICATION="application/json";
	public static final String SET$REF="#/definitions/" ;

	//post
	public static final String POSTSUMMARY="To Create a new record for the entity: ";
	public static final String POSTDESCRIPTION="to be posted";
	//get
	public static final String GETSUMMARY="Entity to be fetched is ";
	public static final String GETDESCRIPTION=" Entity to be fetched";
	


	
}
